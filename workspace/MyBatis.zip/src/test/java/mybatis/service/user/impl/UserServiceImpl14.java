package mybatis.service.user.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import mybatis.service.domain.Search;
import mybatis.service.domain.User;
import mybatis.service.user.UserDao;
import mybatis.service.user.UserService;

@Service("userServiceImpl14")
public class UserServiceImpl14 implements UserService {
	
	@Autowired
	@Qualifier("userDaoImpl14")
	UserDao userDao;
	
	public void setUserDao(UserDao userDao) {
		// TODO Auto-generated constructor stub
		System.out.println("::"+getClass()+".userDao() Call....");
		this.userDao=userDao;
	}
	
	public UserServiceImpl14() {
		// TODO Auto-generated constructor stub
		System.out.println("::"+getClass()+".default Constructor Call....");
	}
	
	// AOP ��ó��
	public int addUser(User user) throws Exception {
		// TODO Auto-generated method stub
		return userDao.addUser(user);
		
//		int result = 0;
//		System.out.println(">>>>>>>>>>>>>>> 1��° insert ===================");
//		result = userDao.addUser(user);
//		System.out.println(">>>>>>>>>>>>>>> 1��° insert ��� : "+result);
//		System.out.println(">>>>>>>>>>>>>>> 2��° insert ===================");
//		result = userDao.addUser(user);
//		System.out.println(">>>>>>>>>>>>>>> 2��° insert ��� : "+result);
//		System.out.println(">>>>>>>>>>>>>>> ����� ???? =====================");
//		return 0;
	}
	////
	public User getUser(String userId) throws Exception {
		// TODO Auto-generated method stub
		return userDao.getUser(userId);
	}

	public int updateUser(User user) throws Exception {
		// TODO Auto-generated method stub
		return userDao.updateUser(user);
	}

	public int removeUser(String userId) throws Exception {
		// TODO Auto-generated method stub
		return userDao.removeUser(userId);
	}

	public List<User> getUserList(Search search) throws Exception {
		// TODO Auto-generated method stub
		return userDao.getUserList(search);
	}

}
