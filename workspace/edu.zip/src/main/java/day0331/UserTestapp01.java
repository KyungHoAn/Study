package day0331;

import org.apache.catalina.User;
import org.apache.naming.factory.BeanFactory;

public class UserTestapp01 {
	public static void main(String[] args) {
		BeanFactory factory =
				new XmlBeanFactory( new FileSystemResource("./src/main/resources/config/hello.xml") );
		System.out.println("=================");
		User user01 = (User)factory.getBean("user01");
		System.out.println(user01);
		
		System.out.println("=================");
		User user02 = (User)factory.getBean("user02");
		System.out.println(user02);
		
		System.out.println("=================");
		User user03 = (User)factory.getBean("user03");
		System.out.println(user03);
		
		System.out.println("=================");
		User user04 = (User)factory.getBean("user04");
		System.out.println(user04);
		
		System.out.println("=================");
		User user05 = (User)factory.getBean("user05");
		System.out.println(user05);
	}

}
