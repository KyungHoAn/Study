package day0331;

import org.apache.catalina.User;

public class UserFactoryBean implements FactoryBean{
	public UserFactoryBean() {
		System.out.println("::"+getClass().getName()+"����Ʈ ������");
	}
	public User getObject() {
		System.out.println("::"+getClass().getName()+".getObject");
		return new User();
	}
	
	public Class getObjectType() {
		System.out.println("::"+getClass().getName()+".getObjecttype()");
		return User.class;
		
	}
	public boolean isSingleton() {
		System.out.println("::"+getClass().getName()+".isSin");
		return true;
	}
	
}
