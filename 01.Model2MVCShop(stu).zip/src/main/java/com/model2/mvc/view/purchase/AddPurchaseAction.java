package com.model2.mvc.view.purchase;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model2.mvc.framework.Action;
import com.model2.mvc.service.product.vo.ProductVO;
import com.model2.mvc.service.purchase.impl.PurchaseServiceImpl;
import com.model2.mvc.service.purchase.service.PurchaseService;
import com.model2.mvc.service.purchase.vo.PurchaseVO;
import com.model2.mvc.service.user.vo.UserVO;

public class AddPurchaseAction extends Action{
	public String execute(	HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		System.out.println("===================");
		System.out.println("test");
		PurchaseVO purchaseVO = new PurchaseVO();
		ProductVO productVO = new ProductVO();
		UserVO userVO = new UserVO();
		
		//userVO session 값 넣기
		
		purchaseVO.setPurchaseProd(productVO);
		purchaseVO.setBuyer(userVO);		
		purchaseVO.setPaymentOption(request.getParameter("paymentOption"));
		purchaseVO.setReceiverName(request.getParameter("receiverName"));
		purchaseVO.setReceiverPhone(request.getParameter("receiverPhone"));
		purchaseVO.setDivyAddr(request.getParameter("receiverAddr"));
		purchaseVO.setDivyRequest(request.getParameter("receiverRequest"));
		purchaseVO.setDivyDate(request.getParameter("receiverDate"));
		purchaseVO.setTranCode("1");
		
		PurchaseService service = new PurchaseServiceImpl();
		service.addPurchase(purchaseVO);
		
		System.out.println("test");
		return "forward:/purchase/addPurchase.jsp";
	}
}



















//public AddPurchaseAction() {
//    // TODO Auto-generated constructor stub
// }
//
// @Override
// public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
//    PurchaseService purchaseService = new PurchaseServiceImpl();
//    ProductService productService = new ProductServiceImpl();
//    
//    PurchaseVO purchaseVO = new PurchaseVO();
//    ProductVO productVO = productService.getProduct(Integer.parseInt(request.getParameter("prodNo")));
//    UserVO userVO = (UserVO) request.getSession().getAttribute("user");
//    
//    //purchaseVO ¼³Á¤
//    purchaseVO.setBuyer(userVO);
//    purchaseVO.setPurchaseProd(productVO);
//    purchaseVO.setPaymentOption(request.getParameter("paymentOption"));
//    purchaseVO.setReceiverName(request.getParameter("receiverName"));
//    purchaseVO.setReceiverPhone(request.getParameter("receiverPhone"));
//    purchaseVO.setDlvyAddr(request.getParameter("receiverAddr"));
//    purchaseVO.setDlvyRequest(request.getParameter("receiverRequest"));
//    purchaseVO.setTranCode("1");
//    purchaseVO.setDlvyDate(request.getParameter("receiverDate"));
//    
//    //½ÇÇà
//    purchaseService.addPurchase(purchaseVO);
//    
//    request.setAttribute("purchaseVO", purchaseVO);
//    
//    return "forward:/purchase/confirmPurchase.jsp";
// }
//
//}