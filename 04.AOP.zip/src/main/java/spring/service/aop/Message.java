package spring.service.aop;

/*
 * FileName : Message.java 
 * :: Message interface Definition
 */
public interface Message {
	
	public String getMessage() throws Exception;
	
	public void setMessage(String message) throws Exception;
	
}//end of class