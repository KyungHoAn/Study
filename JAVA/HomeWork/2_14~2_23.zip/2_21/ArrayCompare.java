//package homework2_21;

//import java.util.Arrays;

public class ArrayCompare {
	private static boolean equalsArr(int[] arr1, int[] arr2) {
		//구현
		if(arr1.length != arr2.length) {
			return false;
		}
		for(int i=0; i<arr1.length; i++) {
			if(arr1[i] == arr2[i]) {
				return true;
			}
		}
//		if(Arrays.equals(arr1, arr2)) {
//			return true;
//		}
		return false;
	}//end of method

	//main method
	public static void main(String[] args) {
		int[] arr1 = { 3, 5, 6, 9, 10, 2, 7 };
		int[] arr2 = { 3, 5, 6, 9, 10, 2, 7 };
		if (equalsArr(arr1, arr2)) {
			System.out.println("1::two array equals");
		} else {
			System.out.println("1::two array not-equals");
		}

		System.out.println("===========");

		int[] arr3 = { 3, 5, 6, 9};
		int[] arr4 = { 3, 5, 6, 9, 8 };
		if (equalsArr(arr3, arr4)) {
			System.out.println("2::two array equals");
		} else {
			System.out.println("2::two array not-equals");
		}
	}// end of main
}// end of class
